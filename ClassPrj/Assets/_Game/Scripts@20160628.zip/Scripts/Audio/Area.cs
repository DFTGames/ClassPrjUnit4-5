﻿using UnityEngine;
using System.Collections;

public class Area : MonoBehaviour {

    public TipiPassi tipiPassiArea = TipiPassi.Acqua;
}

