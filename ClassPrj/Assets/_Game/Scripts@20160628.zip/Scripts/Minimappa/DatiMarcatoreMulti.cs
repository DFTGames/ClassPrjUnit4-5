﻿using UnityEngine;
using System.Collections;

public class DatiMarcatoreMulti : MonoBehaviour {

    public int idUtente = 0;
}
