﻿using UnityEngine;

public class TriggerPortale : MonoBehaviour
{
    public string destinazione = "Villaggio";
}