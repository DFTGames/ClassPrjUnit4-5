﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameListItem : MonoBehaviour {

    public Button button;
    public Text nomeStanza;

    public int roomId;
}
